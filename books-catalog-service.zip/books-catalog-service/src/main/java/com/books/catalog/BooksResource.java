package com.books.catalog;
import com.books.catalog.model.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
//import org.springframework.web.reactive.function.client.WebClient;

@RestController
@RequestMapping("/catalog")
public class BooksResource {
	
	
	@Autowired
	private RestTemplate restTemplate;
	
	/*
	 * @Autowired private WebClient.Builder webClientBuiler;
	 */
	
	@RequestMapping("/{userId}")
	public List<CatalogItem> getCatalogItem(@PathVariable("userId") String userId){
		
		
		//get all rating book id's
		
		// for each book id, call book info service to get the details
		
		//put them all together 
		
		
		
		UserRaings ratings = restTemplate.getForObject("http://localhost:2023/ratingsinfo/users/"+userId, UserRaings.class);
				
		
		/*Arrays.asList(
											new Rating("123", 1),
											new Rating("124", 3),
											new Rating("125", 5)
											);*/
		
		return ratings.getUserRating().stream().map(rating -> {
			
			//below code is for RestClinet usage
			Book book = restTemplate.getForObject("http://localhost:2022/booksinfo/"+rating.getBookId(), Book.class);
			
			//below code is using webclinet which is using REACTIVE programmming
			
			/*
			 * Book book = webClientBuiler.build() .get() // this can be POST, GET, PUT
			 * anything .uri("http://localhost:2022/booksinfo/"+rating.getBookId()) // url
			 * which we are going to use .retrieve() // response .bodyToMono(Book.class) //
			 * passing the book object .block();
			 */
			
			return new CatalogItem(book.getBookName(), "Geetham", rating.getRating());
		
		}).collect(Collectors.toList());
			
		
		
	}
	}
