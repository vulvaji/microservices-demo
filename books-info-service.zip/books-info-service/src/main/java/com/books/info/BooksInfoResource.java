package com.books.info;
import com.books.info.model.*;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/booksinfo")
public class BooksInfoResource {
	@RequestMapping("/{bookId}")
	public Book getBookInfo(@PathVariable("bookId") String bookId) {
		return new Book(bookId, "Super Geetham");
		
	}

}
