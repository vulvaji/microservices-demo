package com.books.ratings;
import com.books.ratings.model.*;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/ratingsinfo")
public class BooksRatingsResource {
	
	@RequestMapping("/{bookId}")
	public Rating getRatingInfo(@PathVariable("bookId")String bookId) {
		return new Rating("Super Geetham", 1);
	}
	
	@RequestMapping("users/{userId}")
	public UserRaings getUserRatingInfo(@PathVariable("userId")String userId) {
		
		List<Rating> ratings = Arrays.asList(
				new Rating("123", 1),
				new Rating("124", 3),
				new Rating("125", 5)
				);
		UserRaings userRatings = new UserRaings();
		userRatings.setUserRating(ratings);
		
		return userRatings;
	}

}
