package com.books.ratings;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableDiscoveryClient
public class BooksRatingsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BooksRatingsServiceApplication.class, args);
	}

}
