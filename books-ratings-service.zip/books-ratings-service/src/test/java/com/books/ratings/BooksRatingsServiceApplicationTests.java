package com.books.ratings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooksRatingsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
